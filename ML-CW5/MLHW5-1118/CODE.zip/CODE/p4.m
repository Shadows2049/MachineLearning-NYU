x1x2 = [0.1,0.7;0.8,0.3];
x2x3 = [0.5,0.1;0.1,0.5];
x3x4 = [0.1,0.5;0.5,0.1];
x4x5 = [0.9,0.3;0.1,0.3];

n=5;
psis = cell(n-1,1);
psis{1} = x1x2;
psis{2} = x2x3;
psis{3} = x3x4;
psis{4} = x4x5;


s = cell(n-2,1);
for i=1:n-2
s{i} = [1,1];
end


for t = 1:n-2
    temp = s{t} ;
    s{t} = sum( psis{t},1 );
    psis{t+1} =repmat( (s{t} ./temp)',1,2) .* psis{t+1};
end 

for k = n-2:-1:1
    temp = s{k} ;
    s{k} = sum( psis{k+1}' );
    psis{k} = repmat(s{k} ./temp,2,1) .* psis{k};
end

for i=1:n-2
    s{i} = s{i}./sum(s{i});
end

for i=1:n-1
    psis{i} = psis{i} ./ sum(sum(psis{i})) ;
end

