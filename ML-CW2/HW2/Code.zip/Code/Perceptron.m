function [theta, iterations,x, Errors, Risk] =  Perceptron(Data)
    theta = rand(3,1) ; %3 1
    t = 1;
    y = Data(:,3); %200 1
    x = [ones(200,1) Data(:,[1,2])]; %200 3
    Errors = [];
    Risk = [];
    err = 10;
    while (err~=0)
        xx = [zeros(200,3)]; %miss classified x, reset
        yy = [zeros(200,1)]; %miss classified y, reset
        err = 0;
        temp = theta;
        k = 1;
        for i = 1:length(Data)
            if(y(i) * (x(i,:) * theta) <= 0)
                xx(k,:) = x(i,:);
                yy(k,:) = y(i);
                k = k+1;
                err= err + 1;
                %disp(xx);
            else
                err = err + 0;
            end
            Errors(t) = err;       
        end
    
        if size(xx)>0 %calculate risk
            Risk(t) = (-1/length(yy))*sum(yy .* (xx * theta));
        end
    
        for i = 1:length(Data) %update theta
            if(y(i) * (x(i,:) * theta) <= 0)
                theta = theta + (y(i) .* x(i,:)');
            end 
        end
        t = t+1;

    end
        iterations = t-1;
end