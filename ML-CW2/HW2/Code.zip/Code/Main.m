load data3.mat
[Theta, Iterations, x, Errors, Risk] = Perceptron(data);

% Perceptron error - iteration plot
figure
plot(1:length(Risk), Risk, '-o');
xlabel("Iterations");
ylabel("Perceptron Error")
title('Perceptron Error');

% Linear decision boundary plot
figure;
A = -(Theta(2)/Theta(3)) * x(:,2) - (Theta(1)/Theta(3));  
B = x(:,2);
plot(A,B, '.');
hold on
plot (x(:,3), x(:,2), 'x');
xlabel("x");
ylabel("y");
title('Decision Boundary');

%Binary classification error plot
figure;
plot (1:length(Errors), Errors);
title('Binary Classification Error');
xlabel("Iterations");
ylabel("Error")
