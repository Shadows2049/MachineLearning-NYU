load teapots.mat

PCA2(teapotImages);
function [] = PCA2(teapotImages)

cv = cov(teapotImages);

% Calculating the eigen Values
[eigVector, eigValues] = eig(cv); 

%eigValues in descending order
[eigVector, eigValues] =sort(eigValues,'descend');

newCoeff = teapotImages * (eigVector(:,1:3));

% recreating the images
z = newCoeff * (eigVector(:,1:3))' ; 
xbar = mean(teapotImages);
centered_data = [];
for i = 1:100
    centered_data = [centered_data; teapotImages(i,:)-xbar];
end
newTeapotImages =z + centered_data;

for i = 1:10    
figure;
imagesc(reshape(teapotImages(i,:),38,50));

figure ;
imagesc(reshape(newTeapotImages(i,:),38,50));
end
end


